package com.example.tarea3_gtics_20206466;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tarea3Gtics20206466ApplicationTests {

	@Test
	void contextLoads() {
	}

}
